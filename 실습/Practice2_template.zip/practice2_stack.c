//Template
#include <stdio.h>
#include <stdlib.h>

typedef struct Node{
	int nData;
	struct Node *next;
}Node;

typedef struct Stack{
	Node *top;
}Stack;

void InitializeStack(Stack *stack);
void Push(Stack *stack, int nData);
int Pop(Stack *stack);


int main(void){
	//source code
	return 0;
}

void InitializeStack(Stack *stack){
	//source code
}

void Push(Stack *stack, int nData){
	//source code
}

int Pop(Stack *stack){
	//source code
}
